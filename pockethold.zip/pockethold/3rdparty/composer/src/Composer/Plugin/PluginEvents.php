<?php











namespace Composer\Plugin;






class PluginEvents
{








const INIT = 'init';









const COMMAND = 'command';









const PRE_FILE_DOWNLOAD = 'pre-file-download';









const PRE_COMMAND_RUN = 'pre-command-run';
}
