<?php











namespace Composer\Plugin\Capability;







interface Capability
{
}
