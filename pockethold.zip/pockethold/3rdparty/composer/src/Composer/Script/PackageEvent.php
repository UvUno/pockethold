<?php











namespace Composer\Script;

use Composer\Installer\PackageEvent as BasePackageEvent;






class PackageEvent extends BasePackageEvent
{
}
