<?php











namespace Composer\Repository;






class InvalidRepositoryException extends \Exception
{
}
