<?php











namespace Composer\EventDispatcher;




class ScriptExecutionException extends \RuntimeException
{
}
