<?php











namespace Composer\Exception;




class NoSslException extends \RuntimeException
{
}
